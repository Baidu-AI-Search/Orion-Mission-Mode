"""
Basic tests for the datautils package.
"""

import datautils


def test_version():
    """Sanity check that the package exposes a version string."""
    assert isinstance(datautils.__version__, str)
    assert datautils.__version__ == "0.1.0"


def test_package_importable():
    """The package should be importable without errors."""
    assert datautils is not None
