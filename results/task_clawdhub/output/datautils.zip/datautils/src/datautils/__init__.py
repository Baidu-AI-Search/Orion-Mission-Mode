"""
datautils - A small utility library for common data processing tasks.
"""

__version__ = "0.1.0"
__all__ = ["__version__"]
