#!/usr/bin/env python3
"""HDFS DataNode log storage analysis (v2 - clean, deduped, comprehensive)."""
import re, json
from collections import defaultdict, Counter
from statistics import mean, median

LOG = "hdfs_datanode.log"

pr_re         = re.compile(r"PacketResponder: Received block (blk_-?\d+) of size (\d+) from /(\d+\.\d+\.\d+\.\d+)")
dx_recv_re    = re.compile(r"DataXceiver: Received block (blk_-?\d+) src: /(\d+\.\d+\.\d+\.\d+):\d+ dest: /(\d+\.\d+\.\d+\.\d+):\d+ of size (\d+)")
alloc_re      = re.compile(r"NameSystem\.allocateBlock: (\S+)\s+(blk_-?\d+)")
addstored_re  = re.compile(r"NameSystem\.addStoredBlock: blockMap updated: (\d+\.\d+\.\d+\.\d+):\d+ is added to (blk_-?\d+) size (\d+)")
ts_re         = re.compile(r"^(\d{6})\s+(\d{6})")

def ts_to_sec(line):
    m = ts_re.match(line)
    if not m: return None
    t = m.group(2)
    return int(t[0:2])*3600 + int(t[2:4])*60 + int(t[4:6])

# Data
block_size = {}
block_nodes_confirmed = defaultdict(set)   # blk -> set(datanode IP) that "Received" it
node_bytes = defaultdict(int)
node_blocks = defaultdict(set)

nn_block_nodes = defaultdict(set)          # blk -> set(IP) per addStoredBlock
nn_node_bytes = defaultdict(int)

alloc_paths = []
alloc_block_paths = {}
alloc_events = []      # (sec, blk, path)
recv_events = []       # (sec, blk, node, size)

first_ts = None
last_ts = None

def touch(t):
    global first_ts, last_ts
    if t is None: return
    if first_ts is None or t < first_ts: first_ts = t
    if last_ts  is None or t > last_ts:  last_ts  = t

with open(LOG, "r") as f:
    for line in f:
        t = ts_to_sec(line)
        touch(t)

        m = pr_re.search(line)
        if m:
            blk, sz, ip = m.group(1), int(m.group(2)), m.group(3)
            block_size[blk] = sz
            if ip not in block_nodes_confirmed[blk]:
                block_nodes_confirmed[blk].add(ip)
                node_bytes[ip] += sz
                node_blocks[ip].add(blk)
                if t is not None:
                    recv_events.append((t, blk, ip, sz))
            continue

        m = dx_recv_re.search(line)
        if m:
            blk, src, dest, sz = m.group(1), m.group(2), m.group(3), int(m.group(4))
            block_size[blk] = sz
            if dest not in block_nodes_confirmed[blk]:
                block_nodes_confirmed[blk].add(dest)
                node_bytes[dest] += sz
                node_blocks[dest].add(blk)
                if t is not None:
                    recv_events.append((t, blk, dest, sz))
            continue

        m = alloc_re.search(line)
        if m:
            path, blk = m.group(1), m.group(2)
            alloc_paths.append(path)
            alloc_block_paths[blk] = path
            if t is not None:
                alloc_events.append((t, blk, path))
            continue

        m = addstored_re.search(line)
        if m:
            ip, blk, sz = m.group(1), m.group(2), int(m.group(3))
            block_size.setdefault(blk, sz)
            if ip not in nn_block_nodes[blk]:
                nn_block_nodes[blk].add(ip)
                nn_node_bytes[ip] += sz
            continue

# ---------- Aggregates ----------
unique_blocks_with_size = [b for b in block_size if block_nodes_confirmed.get(b) or nn_block_nodes.get(b)]
# For "confirmed block receives where size is known" — blocks that appear in PR/DX received
confirmed_blocks = [b for b in block_size if block_nodes_confirmed.get(b)]
total_confirmed_bytes = sum(block_size[b] for b in confirmed_blocks)

# Cluster bytes (sum of size * replica count for confirmed)
total_cluster_bytes_confirmed = 0
for b in confirmed_blocks:
    total_cluster_bytes_confirmed += block_size[b] * len(block_nodes_confirmed[b])

# Block size distribution
sizes = [block_size[b] for b in confirmed_blocks]
sizes_sorted = sorted(sizes)

def stats(vals):
    if not vals: return None
    return {
        "count": len(vals),
        "min": min(vals),
        "max": max(vals),
        "mean": mean(vals),
        "median": median(vals),
    }
size_stats = stats(sizes)
size_hist = Counter(sizes)

# Node distribution (from confirmed receives)
node_dist = sorted(
    [(ip, node_bytes[ip], len(node_blocks[ip])) for ip in node_bytes],
    key=lambda x: -x[1]
)

# Also build NN view (addStoredBlock) — nodes for which NameNode recorded successful storage
nn_node_dist = sorted(
    [(ip, nn_node_bytes[ip], len(nn_block_nodes_for_ip := [b for b in nn_block_nodes if ip in nn_block_nodes[b]])) for ip in nn_node_bytes],
    key=lambda x: -x[1]
)

# Path prefix analysis
def top_prefix(path):
    p = path.strip("/").split("/")
    if len(p) >= 2:
        return "/" + p[0] + "/" + p[1]
    return "/" + p[0] if p else "/"

prefix_counts = Counter(top_prefix(p) for p in alloc_paths)
# deeper category (first 3 segments)
def cat3(path):
    p = path.strip("/").split("/")
    if len(p) >= 3:
        return "/" + "/".join(p[:3])
    return "/" + "/".join(p)
cat3_counts = Counter(cat3(p) for p in alloc_paths)

# Replication factor — for confirmed blocks, count distinct receiving nodes
repl_confirmed = [len(block_nodes_confirmed[b]) for b in confirmed_blocks if block_nodes_confirmed[b]]
repl_stats_confirmed = stats(repl_confirmed)

# For blocks that appear in addStoredBlock, count replicas there (wider NameNode view)
repl_nn = [len(nn_block_nodes[b]) for b in nn_block_nodes if nn_block_nodes[b]]
repl_stats_nn = stats(repl_nn)

# Effective replication factor = total cluster bytes / logical bytes
eff_repl = total_cluster_bytes_confirmed / total_confirmed_bytes if total_confirmed_bytes else 0

# ---------- Capacity planning ----------
duration = (last_ts - first_ts) if (first_ts is not None and last_ts is not None) else 0
# Use allocateBlock events as the authoritative "blocks ingested" rate (each allocateBlock = new client write)
# But many of those allocations don't have confirmed size in this log snapshot. So for size-based rate, use confirmed completes.
logical_rate_bps = total_confirmed_bytes / duration if duration > 0 else 0
cluster_rate_bps = total_cluster_bytes_confirmed / duration if duration > 0 else 0

# Allocation rate (blocks/sec) — captures write throughput including blocks that haven't confirmed yet in the window
alloc_rate = len(alloc_events) / duration if duration > 0 else 0
# Average block size (logical)
avg_block_size = mean(sizes) if sizes else 0
# Estimated logical ingest rate using allocations * avg block size
logical_rate_alloc_bps = alloc_rate * avg_block_size
cluster_rate_alloc_bps = logical_rate_alloc_bps * eff_repl

hour_logical = logical_rate_bps * 3600
hour_cluster = cluster_rate_bps * 3600
hour_logical_alloc = logical_rate_alloc_bps * 3600
hour_cluster_alloc = cluster_rate_alloc_bps * 3600

# ---------- Humanize ----------
def human_bytes(n):
    n = float(n)
    for u in ["B","KB","MB","GB","TB","PB"]:
        if abs(n) < 1024: return f"{n:,.2f} {u}"
        n /= 1024
    return f"{n:,.2f} EB"

result = {
    "duration_sec": duration,
    "confirmed_block_count": len(confirmed_blocks),
    "total_confirmed_bytes_logical": total_confirmed_bytes,
    "total_cluster_bytes_with_repl": total_cluster_bytes_confirmed,
    "size_stats": size_stats,
    "size_hist": dict(sorted(size_hist.items())),
    "node_dist": node_dist,
    "node_count": len(node_bytes),
    "nn_node_count": len(nn_node_bytes),
    "nn_node_dist_top": nn_node_dist[:20],
    "prefix_counts": dict(prefix_counts.most_common()),
    "cat3_counts": dict(cat3_counts.most_common(10)),
    "alloc_event_count": len(alloc_events),
    "recv_event_count": len(recv_events),
    "repl_stats_confirmed": repl_stats_confirmed,
    "repl_stats_nn": repl_stats_nn,
    "repl_hist_confirmed": dict(Counter(repl_confirmed)),
    "repl_hist_nn": dict(Counter(repl_nn)),
    "eff_repl": eff_repl,
    "logical_rate_bps": logical_rate_bps,
    "cluster_rate_bps": cluster_rate_bps,
    "alloc_rate_per_sec": alloc_rate,
    "avg_block_size": avg_block_size,
    "hour_logical": hour_logical,
    "hour_cluster": hour_cluster,
    "hour_logical_alloc": hour_logical_alloc,
    "hour_cluster_alloc": hour_cluster_alloc,
}
print(json.dumps(result, indent=2, default=str))

# Save for report writing
with open("analysis.json","w") as f:
    json.dump(result, f, indent=2, default=str)
