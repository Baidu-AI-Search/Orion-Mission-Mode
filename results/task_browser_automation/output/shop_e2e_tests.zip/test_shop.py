"""
Playwright end-to-end tests for TechMart shop page.
Usage:
    pip install playwright
    playwright install chromium
    pytest test_shop.py
"""
import os
import re
from playwright.sync_api import Page, expect


WORKSPACE = os.path.dirname(os.path.abspath(__file__))
SHOP_URL = f"file://{WORKSPACE}/shop.html"


def test_webcam_out_of_stock_button_disabled(page: Page):
    """The 'Webcam HD 1080p' product (stock=0) must have a disabled Add to Cart button."""
    page.goto(SHOP_URL)
    webcam = page.locator(".product", has_text="Webcam HD 1080p")
    expect(webcam).to_be_visible()
    expect(webcam.locator(".stock")).to_have_text("Out of stock")
    btn = webcam.get_by_role("button", name="Add to Cart")
    expect(btn).to_be_disabled()


def test_full_shopping_flow(page: Page):
    """Full happy-path: add items, update qty, check totals, remove, checkout."""
    page.goto(SHOP_URL)

    # 1. Add Wireless Mouse
    mouse_card = page.locator(".product", has_text="Wireless Mouse")
    mouse_card.get_by_role("button", name="Add to Cart").click()

    # 2. Add Mechanical Keyboard
    kb_card = page.locator(".product", has_text="Mechanical Keyboard")
    kb_card.get_by_role("button", name="Add to Cart").click()

    # 3. Add a second Wireless Mouse (qty becomes 2)
    mouse_card.get_by_role("button", name="Add to Cart").click()

    # 4. Verify cart items are listed correctly
    cart_items = page.locator("#cart-items li")
    expect(cart_items).to_have_count(2)
    expect(cart_items.filter(has_text="Wireless Mouse × 2")).to_be_visible()
    expect(cart_items.filter(has_text="Mechanical Keyboard × 1")).to_be_visible()

    # 5. Verify total = $149.97 (29.99*2 + 89.99)
    expect(page.locator("#total")).to_have_text("Total: $149.97")

    # 6. Remove Mechanical Keyboard from cart
    cart_items.filter(has_text="Mechanical Keyboard").locator(".remove").click()
    expect(cart_items).to_have_count(1)
    expect(cart_items.filter(has_text="Wireless Mouse × 2")).to_be_visible()

    # 7. Verify updated total = $59.98 (29.99*2)
    expect(page.locator("#total")).to_have_text("Total: $59.98")

    # 8. Click Checkout
    checkout_btn = page.locator("#checkout")
    expect(checkout_btn).to_be_enabled()
    checkout_btn.click()

    # 9. Verify order confirmation appears with ORD- prefixed order ID
    confirmation = page.locator("#order-confirmation")
    expect(confirmation).to_be_visible()
    expect(confirmation).to_contain_text("Order Confirmed!")

    order_id_el = page.locator("#order-id")
    expect(order_id_el).to_be_visible()
    order_id_text = order_id_el.text_content()
    assert order_id_text is not None
    assert order_id_text.startswith("ORD-"), f"Order ID '{order_id_text}' must start with 'ORD-'"
    assert re.fullmatch(r"ORD-[A-Z0-9]{6}", order_id_text), f"Unexpected order ID format: {order_id_text}"

    # Cart should be hidden after checkout
    expect(page.locator("#cart")).not_to_be_visible()
    expect(page.locator(".products")).not_to_be_visible()
