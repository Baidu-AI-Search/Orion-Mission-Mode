import pandas as pd
import numpy as np

df = pd.read_csv('/home/user/da2e7465ecf346e4a597f98086b1da2f/us_cities_top1000.csv')
print(df.shape)
print(df.dtypes)
print(df.describe())

# 1. Centroids
total_pop = df['Population'].sum()
w_lat = (df['lat'] * df['Population']).sum() / total_pop
w_lon = (df['lon'] * df['Population']).sum() / total_pop
u_lat = df['lat'].mean()
u_lon = df['lon'].mean()
print(f"\nWeighted centroid: {w_lat:.4f}N, {w_lon:.4f}W")
print(f"Unweighted centroid: {u_lat:.4f}N, {u_lon:.4f}W")
print(f"Diff lat: {w_lat-u_lat:.4f}, lon: {w_lon-u_lon:.4f}")

# 2. Extremes
n_city = df.loc[df['lat'].idxmax()]
s_city = df.loc[df['lat'].idxmin()]
e_city = df.loc[df['lon'].idxmax()]  # least negative = easternmost
w_city = df.loc[df['lon'].idxmin()]
print("\nExtremes:")
for label, c in [('North', n_city), ('South', s_city), ('East', e_city), ('West', w_city)]:
    print(f"  {label}: {c['City']}, {c['State']} | pop={c['Population']:,} | lat={c['lat']:.4f} lon={c['lon']:.4f}")

# 3. Latitude bands
def band(lat):
    if lat < 30: return 'Below 30°N'
    if lat < 35: return '30–35°N'
    if lat < 40: return '35–40°N'
    if lat < 45: return '40–45°N'
    return 'Above 45°N'

bands_order = ['Below 30°N','30–35°N','35–40°N','40–45°N','Above 45°N']
df['band'] = df['lat'].apply(band)
g = df.groupby('band').agg(count=('City','count'), total_pop=('Population','sum'), avg_pop=('Population','mean'))
g = g.reindex(bands_order)
g['avg_pop'] = g['avg_pop'].round(0).astype('Int64')
print("\nLatitude bands:")
print(g)

# 4. East-West split at -95
east = df[df['lon'] > -95]
west = df[df['lon'] <= -95]
print(f"\nEast: cities={len(east)}, pop={east['Population'].sum():,}, avg={east['Population'].mean():,.0f}")
print(f"West: cities={len(west)}, pop={west['Population'].sum():,}, avg={west['Population'].mean():,.0f}")

# 5. State spread for states with 10+ cities
state_counts = df['State'].value_counts()
big_states = state_counts[state_counts >= 10].index.tolist()
rows = []
for st in big_states:
    sub = df[df['State']==st]
    lat_spread = sub['lat'].max() - sub['lat'].min()
    lon_spread = sub['lon'].max() - sub['lon'].min()
    diag = np.hypot(lat_spread, lon_spread)
    rows.append((st, len(sub), lat_spread, lon_spread, diag))
spread_df = pd.DataFrame(rows, columns=['State','cities','lat_spread','lon_spread','diag_deg'])
spread_df = spread_df.sort_values('diag_deg', ascending=False)
print("\nState spread (top 15 by diagonal):")
print(spread_df.head(15).to_string(index=False))
