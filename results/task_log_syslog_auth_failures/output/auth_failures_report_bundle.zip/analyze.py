#!/usr/bin/env python3
"""Analyze syslog for auth failures and produce markdown report."""
import re
from collections import Counter, defaultdict
from datetime import datetime

LOG = "/home/user/17b28cfa415a483d96fa9078a1a5764e/syslog.log"

line_re = re.compile(r'^(\w+\s+\d+\s+\d+:\d+:\d+)\s+\S+\s+([^:\[]+?)(?:\(pam_unix\))?\[\d+\]:\s*(.*)$')

MONTHS = {m: i+1 for i, m in enumerate(
    ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"])}
YEAR = 2005

def parse_ts(s):
    parts = s.split()
    mon = MONTHS[parts[0]]
    day = int(parts[1])
    hh, mm, ss = [int(x) for x in parts[2].split(":")]
    return datetime(YEAR, mon, day, hh, mm, ss)

pam_fails = []      # (ts, service, rhost, user)
ftpd_conns = []
ftpd_anons = []
ftpd_unknowns = []
klogind_fails = []

ftpd_conn_re = re.compile(r'ftpd\[\d+\]:\s*connection from\s+(\S+)')
ftpd_anon_re = re.compile(r'ftpd\[\d+\]:\s*ANONYMOUS FTP LOGIN FROM\s+([0-9.]+)')
ftpd_unk_re  = re.compile(r'ftpd\[\d+\]:\s*User unknown timed out')
klogind_re   = re.compile(r'klogind\[\d+\]:\s*Authentication failed from\s+(\S+)')

rhost_re = re.compile(r'rhost=(\S*)')
user_re  = re.compile(r'\buser=(\S+)')
unknown_user_re = re.compile(r'check pass;\s*user unknown', re.I)

with open(LOG, encoding="latin-1", errors="replace") as f:
    for line in f:
        line = line.rstrip("\n")
        m = line_re.match(line)
        if not m:
            # still check ftpd/klogind
            pass
        else:
            ts_str, svc, msg = m.groups()
            svc = svc.strip()
            ts = parse_ts(ts_str)
            if "authentication failure" in msg:
                rm = rhost_re.search(msg)
                um = user_re.search(msg)
                rhost = (rm.group(1) if rm else "").strip()
                user  = (um.group(1) if um else "").strip()
                if not user and unknown_user_re.search(msg):
                    user = "(unknown)"
                if not rhost:
                    # local login / gdm
                    rhost = "localhost"
                pam_fails.append((ts, svc, rhost, user))
                continue
        # ftpd / klogind
        m2 = ftpd_conn_re.search(line)
        if m2:
            ts_str = line[:15]
            try:
                ftpd_conns.append((parse_ts(ts_str), m2.group(1)))
            except Exception:
                pass
            continue
        if ftpd_anon_re.search(line):
            ts_str = line[:15]
            mm = ftpd_anon_re.search(line)
            try:
                ftpd_anons.append((parse_ts(ts_str), mm.group(1)))
            except Exception:
                pass
            continue
        if ftpd_unk_re.search(line):
            ts_str = line[:15]
            try:
                ftpd_unknowns.append((parse_ts(ts_str), None))
            except Exception:
                pass
            continue
        mk = klogind_re.search(line)
        if mk:
            ts_str = line[:15]
            try:
                klogind_fails.append((parse_ts(ts_str), mk.group(1)))
            except Exception:
                pass

total_pam = len(pam_fails)
total_ftpd_conn = len(ftpd_conns)
total_ftpd_anon = len(ftpd_anons)
total_ftpd_unknown = len(ftpd_unknowns)
total_klogind = len(klogind_fails)

svc_counter = Counter(s for _, s, _, _ in pam_fails)
src_counter = Counter(r for _, _, r, _ in pam_fails if r and r != "localhost")
ftp_src_counter = Counter(ip for _, ip in ftpd_conns)
user_counter = Counter(u for _, _, _, u in pam_fails if u)
unknown_user_pam = sum(1 for _, _, _, u in pam_fails if u == "(unknown)")

hour_counter = Counter(t.hour for t, *_ in pam_fails)
day_counter = Counter(t.strftime("%Y-%m-%d") for t, *_ in pam_fails)
day_sorted = sorted(day_counter.items())

ssh_fails = [(t, r, u) for t, s, r, u in pam_fails if s == "sshd"]
ssh_src_counter = Counter(r for _, r, _ in ssh_fails if r)
ssh_user_counter = Counter(u for _, _, u in ssh_fails)
ssh_hour = Counter(t.hour for t, *_ in ssh_fails)

ftp_src_times = defaultdict(list)
for ts, ip in ftpd_conns:
    ftp_src_times[ip].append(ts)
ftp_src_summary = []
ftp_bursts = []  # short-burst sources (span < 5 minutes) — classic parallel brute force
for ip, times in sorted(ftp_src_times.items(), key=lambda x: -len(x[1])):
    ts_ = sorted(times)
    span = (ts_[-1] - ts_[0]).total_seconds()
    rec = (ip, len(ts_), ts_[0], ts_[-1], span)
    ftp_src_summary.append(rec)
    if span < 300:
        ftp_bursts.append(rec)
ftp_bursts.sort(key=lambda x: -x[1])

ssh_sources = set(r for r, c in ssh_src_counter.items())
ftp_sources = set(ip for _, ip in ftpd_conns)
overlap = ssh_sources & ftp_sources

all_times = [t for t, *_ in pam_fails] + [t for t, _ in ftpd_conns] + [t for t, _ in klogind_fails]
all_times = [t for t in all_times if t is not None]
tmin, tmax = min(all_times), max(all_times)

# Build ranked lists
user_rank = {u: i+1 for i, (u, _) in enumerate(user_counter.most_common())}

lines = []
lines.append("# Authentication Failures Analysis Report")
lines.append("")
lines.append(f"**Log file:** `syslog.log`  ")
lines.append(f"**Hostname:** `combo`  ")
lines.append(f"**Log time span:** {tmin.strftime('%Y-%m-%d %H:%M:%S')} → {tmax.strftime('%Y-%m-%d %H:%M:%S')}  ")
lines.append("")
lines.append("---")
lines.append("")
lines.append("## Executive Summary")
lines.append("")
lines.append(f"The host is under active, sustained **brute-force attack**, primarily against **SSH** and secondarily against **FTP**. Over the log window we observed **{total_pam} explicit PAM authentication failures** ({svc_counter.get('sshd',0)} against SSH), plus **{total_klogind} Kerberos klogind failures** and **{total_ftpd_conn} FTP connection-probe attempts** launched in high-parallelism bursts. Attacks originate from dozens of distinct sources, with `root` overwhelmingly the most-targeted user and attacks distributed uniformly across all hours of the day — the signature of automated botnets, not human actors.")
lines.append("")
lines.append("---")
lines.append("")
lines.append("## 1. Total Authentication Failures")
lines.append("")
lines.append("| Category | Count |")
lines.append("|---|---:|")
lines.append(f"| PAM `authentication failure` events | **{total_pam}** |")
lines.append(f"| └ SSH (`sshd`) | {svc_counter.get('sshd',0)} |")
lines.append(f"| └ Console `login` | {svc_counter.get('login',0)} |")
lines.append(f"| └ GDM (graphical login) | {svc_counter.get('gdm',0)} |")
lines.append(f"| Kerberos `klogind` authentication failures | {total_klogind} |")
lines.append(f"| FTP connection probes (brute-force initiations) | {total_ftpd_conn} |")
lines.append(f"| FTP `User unknown timed out` sessions | {total_ftpd_unknown} |")
lines.append(f"| FTP anonymous login attempts | {total_ftpd_anon} |")
lines.append("")
lines.append(f"> **Total explicit auth failures: {total_pam + total_klogind}** (PAM + klogind). The FTP daemon does not emit PAM failure lines in this configuration, so {total_ftpd_conn} FTP connection attempts are reported separately as attack indicators.")
lines.append("")
lines.append("---")
lines.append("")
lines.append("## 2. Failures by Service")
lines.append("")
lines.append("| Service | Auth Failures | Share |")
lines.append("|---|---:|---:|")
for svc, c in svc_counter.most_common():
    lines.append(f"| `{svc}` | {c} | {c/total_pam*100:.1f}% |")
lines.append(f"| `klogind` (Kerberos, non-PAM) | {total_klogind} | — |")
lines.append(f"| `ftpd` (FTP probes — no PAM failure lines) | {total_ftpd_conn} attempts | — |")
lines.append("")
ssh_share = svc_counter.get('sshd',0)/total_pam*100
lines.append(f"**Key observation:** SSH dominates ({ssh_share:.1f}% of all PAM failures). Only {svc_counter.get('login',0)} console `login` failures and {svc_counter.get('gdm',0)} GDM failure appear — local/physical access is not a meaningful attack vector in this window.")
lines.append("")
lines.append("Note: `su` session open/close events appear in the log, but all are legitimate (cron-initiated `su` to service accounts like `cyrus`, `news`, `htt`); **no `su` authentication failures** were logged.")
lines.append("")
lines.append("---")
lines.append("")
lines.append("## 3. Top 10 Source Hosts/IPs — PAM Failures (mostly SSH)")
lines.append("")
lines.append(f"Total unique PAM-failure sources: **{len(src_counter)}**")
lines.append("")
lines.append("| Rank | Source host / IP | Failures | Share |")
lines.append("|---:|---|---:|---:|")
top10 = src_counter.most_common(10)
for i, (src, c) in enumerate(top10, 1):
    lines.append(f"| {i} | `{src}` | {c} | {c/total_pam*100:.1f}% |")
lines.append("")
lines.append("Attack sources resolve to a mix of:")
lines.append("- Compromised servers in hosting providers (e.g. `sagonet.net`)")
lines.append("- Consumer/residential broadband (e.g. `astral.ro`, various `.net`/`.com` reverse DNS)")
lines.append("- Dial-up and early-cable ISP pools (consistent with the 2005-era log)")
lines.append("")
lines.append("This broad source distribution is characteristic of a **distributed botnet** rather than a single attacker.")
lines.append("")
lines.append("### FTP connection-probe sources (all)")
lines.append("")
lines.append(f"Total unique FTP source IPs: **{len(ftp_src_counter)}**")
lines.append("")
lines.append("| Rank | Source IP | Connections | First seen | Last seen | Duration | Avg rate |")
lines.append("|---:|---|---:|---|---|---:|---:|")
for i, (ip, n, t1, t2, span) in enumerate(ftp_src_summary[:10], 1):
    dur = f"{span:.0f}s" if span < 60 else (f"{span/60:.1f}min" if span < 3600 else f"{span/3600:.1f}h")
    rate_per_min = n / max(span/60, 1.0)
    lines.append(f"| {i} | `{ip}` | {n} | {t1.strftime('%b %d %H:%M')} | {t2.strftime('%b %d %H:%M')} | {dur} | {rate_per_min:.2f}/min |")
lines.append("")
lines.append(f"### FTP short-burst sources (parallel brute-force floods, < 5 min)")
lines.append("")
lines.append(f"{len(ftp_bursts)} source(s) opened all their connections in under 5 minutes — the hallmark of parallel dictionary attacks. Top burst sources:")
lines.append("")
lines.append("| Source IP | Connections | All in | At time |")
lines.append("|---|---:|---:|---|")
for ip, n, t1, t2, span in ftp_bursts[:10]:
    if span < 1:
        dur_str = "< 1 s"
    elif span < 60:
        dur_str = f"{span:.0f} s"
    else:
        dur_str = f"{span/60:.1f} min"
    lines.append(f"| `{ip}` | {n} | {dur_str} | {t1.strftime('%b %d %H:%M:%S')} |")
lines.append("")
lines.append("Two distinct FTP patterns are visible: (a) **recurring low-rate probes** (e.g. `211.107.232.1` with 149 connections across ~60 days) and (b) **instant parallel floods** (e.g. 23 simultaneous connections from multiple IPs within the same second), the latter being typical of tools like `hydra`/`medusa` running parallel threads.")
lines.append("")
lines.append("---")
lines.append("")
lines.append("## 4. Targeted User Accounts")
lines.append("")
lines.append("| Rank | Username | Failed Attempts | Share |")
lines.append("|---:|---|---:|---:|")
for i, (u, c) in enumerate(user_counter.most_common(15), 1):
    display = "*(invalid/unknown user)*" if u == "(unknown)" else f"`{u}`"
    lines.append(f"| {i} | {display} | {c} | {c/total_pam*100:.1f}% |")
lines.append("")
root_count = user_counter.get("root", 0)
lines.append(f"- **`root` is the dominant target** with {root_count} failures ({root_count/total_pam*100:.1f}% of all PAM failures). The classic SSH brute-force playbook is to prioritize the superuser account.")
lines.append(f"- **Invalid / non-existent usernames** (`check pass; user unknown`) account for **{unknown_user_pam}** failures ({unknown_user_pam/total_pam*100:.1f}%), indicating username dictionary enumeration against common service names (test, admin, oracle, mysql, etc.).")
lines.append("")
non_root = [(u,c) for u,c in user_counter.most_common() if u not in ("root","(unknown)")][:10]
if non_root:
    lines.append("**Top non-root, non-unknown usernames targeted:**")
    lines.append("")
    lines.append("| Username | Attempts | Typical role |")
    lines.append("|---|---:|---|")
    notes = {
        "admin":"common admin account", "oracle":"Oracle DB", "mysql":"MySQL DB",
        "postgres":"PostgreSQL", "test":"default test account", "guest":"default guest",
        "ftp":"FTP user", "www":"web server", "nobody":"default unprivileged",
        "operator":"legacy admin", "webmaster":"web admin", "user":"default user",
        "support":"IT support", "postfix":"mail", "mail":"mail",
    }
    for u, c in non_root:
        lines.append(f"| `{u}` | {c} | {notes.get(u,'')} |")
    lines.append("")
lines.append("---")
lines.append("")
lines.append("## 5. Temporal Distribution")
lines.append("")
lines.append("### 5.1 Failures by hour of day (PAM)")
lines.append("")
max_h = max(hour_counter.values()) if hour_counter else 1
lines.append("| Hour | Failures | |")
lines.append("|---:|---:|---|")
for h in range(24):
    c = hour_counter.get(h, 0)
    bar = "█" * max(1, int(40 * c / max_h)) if c else ""
    lines.append(f"| {h:02d}:00 | {c} | {bar} |")
lines.append("")
peak_hour, peak_hour_count = hour_counter.most_common(1)[0]
night = sum(c for h,c in hour_counter.items() if h < 6 or h >= 22)
business = sum(c for h,c in hour_counter.items() if 9 <= h <= 17)
lines.append(f"- **Peak hour:** {peak_hour:02d}:00 with {peak_hour_count} failures.")
lines.append(f"- **Night-time (22:00–06:00):** {night} failures ({night/total_pam*100:.1f}%).")
lines.append(f"- **Business hours (09:00–17:00):** {business} failures ({business/total_pam*100:.1f}%).")
lines.append("- Traffic is essentially **flat across the clock** — the signature of automated bots running in different time zones, not humans.")
lines.append("")
lines.append("### 5.2 Failures by day")
lines.append("")
max_d = max(c for _, c in day_sorted) if day_sorted else 1
lines.append("| Date | Failures | |")
lines.append("|---|---:|---|")
for d, c in day_sorted:
    bar = "█" * max(1, int(40 * c / max_d))
    lines.append(f"| {d} | {c} | {bar} |")
lines.append("")
peak_day, peak_day_count = max(day_sorted, key=lambda x: x[1])
lines.append(f"- **Heaviest day:** {peak_day} with {peak_day_count} failures (a concentrated brute-force burst from a coordinated source set).")
lines.append(f"- **Log coverage:** {len(day_sorted)} distinct days with PAM failures between {tmin.strftime('%Y-%m-%d')} and {tmax.strftime('%Y-%m-%d')}.")
lines.append("")
lines.append("---")
lines.append("")
lines.append("## 6. FTP vs SSH Attack Pattern Comparison")
lines.append("")
lines.append("### 6.1 Side-by-side")
lines.append("")
lines.append("| Attribute | SSH (`sshd`) | FTP (`ftpd`) |")
lines.append("|---|---|---|")
lines.append(f"| Explicit PAM failures logged | {len(ssh_fails)} | 0 (ftpd not using PAM or logging elsewhere) |")
lines.append(f"| Connection/attempt volume | {len(ssh_fails)} failure events | {total_ftpd_conn} TCP connection initiations |")
lines.append(f"| Unique sources | {len(ssh_src_counter)} | {len(ftp_src_counter)} |")
ssh_target = ssh_user_counter.most_common(1)[0] if ssh_user_counter else ("?",0)
lines.append(f"| Primary target user | `{ssh_target[0]}` ({ssh_target[1]} attempts) | unknown (usernames not logged in connection line) |")
lines.append(f"| Top source count | {ssh_src_counter.most_common(1)[0][1] if ssh_src_counter else 0} failures from top host | {ftp_src_summary[0][1] if ftp_src_summary else 0} connections from top IP |")
lines.append(f"| Connection pattern | Slow, distributed: a few attempts per host spread over days | Fast, concentrated: bursts of 20+ simultaneous connections per source in seconds |")
lines.append("")
lines.append("### 6.2 Do the same sources attack both services?")
lines.append("")
lines.append(f"- SSH source set size: **{len(ssh_sources)}** hosts (reverse-DNS names)")
lines.append(f"- FTP source set size: **{len(ftp_sources)}** IPs")
lines.append(f"- **Overlap (exact string match): {len(overlap)}**")
lines.append("")
if overlap:
    lines.append("Overlapping sources:")
    for s in sorted(overlap):
        lines.append(f"- `{s}`")
else:
    lines.append("> **No direct overlap is visible in this log.**")
    lines.append("")
    lines.append("Two reasons this is expected:")
    lines.append("1. **Naming mismatch:** SSH failures are logged with the *reverse-DNS hostname* of the attacker (e.g. `unknown.sagonet.net`), while FTP connection lines log the *raw IP address*. Without performing PTR lookups on the FTP IPs we cannot definitively cross-correlate, but the sets are labeled differently in the log.")
    lines.append("2. **Two distinct bot classes:** Observed behavior strongly suggests different tools/campaigns — SSH traffic is a low-and-slow distributed root-password dictionary with username enumeration, while FTP traffic is a high-parallelism connection flood (a different tooling profile). It is common for different botnets to specialize in one protocol.")
lines.append("")
lines.append("**Practical implication:** Blocking the top SSH sources will *not* stop the FTP floods, and vice-versa. Defenses must be applied independently to both services (see §7).")
lines.append("")
lines.append("### 6.3 Other noteworthy remote-auth traffic")
lines.append("")
lines.append(f"- **Kerberos `klogind`:** {total_klogind} failures in a tight burst from a single IP `163.27.187.39` (including `Permission denied in replay cache code` errors, suggesting a replay-style attack against legacy Kerberos remote-login).")
lines.append("- **Telnet:** `xinetd` fails to start telnet on boot because the port is already bound — this should be investigated and telnet explicitly disabled; telnet must not be exposed even accidentally.")
lines.append("")
lines.append("---")
lines.append("")
lines.append("## 7. Recommendations")
lines.append("")
lines.append("The host is running a very old Red Hat-derived distribution (kernel 2.6.5-1.358, ~2004) and is exposed to continuous automated attack. Recommendations are grouped by priority:")
lines.append("")
lines.append("### 7.1 Critical — apply immediately")
lines.append("")
lines.append("1. **Disable direct root SSH login.** Set `PermitRootLogin no` (or `prohibit-password`) in `/etc/ssh/sshd_config` and restart sshd. This single change neutralizes >{0:.0f}% of observed SSH failures.".format(root_count/total_pam*100))
lines.append("2. **Switch SSH to key-based authentication and disable password auth** (`PasswordAuthentication no`). Every observed SSH failure is a password-guess; public-key auth defeats the entire attack class.")
lines.append("3. **Install & enable `fail2ban`** (or `sshguard`) with jails for `sshd`, `ftpd`/`vsftpd`, and any other exposed service. With the observed rate, a ban threshold of 5 failures / 10 min would have blocked the top sources within seconds of each burst.")
lines.append("4. **Retire FTP in favor of SFTP** (which runs over SSH and inherits SSH key-auth protections). If FTP *must* stay:")
lines.append("   - Disable anonymous login (`anonymous_enable=NO`).")
lines.append("   - Use FTPS (TLS) so credentials aren't sent in cleartext.")
lines.append("   - Run it chrooted and restrict to a dedicated non-shell account.")
lines.append("   - Rate-limit connections per source IP (e.g. `max_per_ip` in vsftpd, plus iptables rules).")
lines.append("5. **Disable legacy BSD r-services (rsh/rlogin/klogind) and telnet.** The Kerberos klogind burst and the telnet port-bind failure both indicate legacy remote-login daemons that should not be on an internet-connected host.")
lines.append("")
lines.append("### 7.2 Network / firewall hardening")
lines.append("")
lines.append("6. **Rate-limit new connections** with iptables/nftables, e.g.:")
lines.append("   ```")
lines.append("   iptables -A INPUT -p tcp --dport 22 -m conntrack --ctstate NEW -m recent --set")
lines.append("   iptables -A INPUT -p tcp --dport 22 -m conntrack --ctstate NEW -m recent --update --seconds 60 --hitcount 6 -j DROP")
lines.append("   ```")
lines.append("   Apply equivalent rules for FTP (port 21) and any other exposed service.")
lines.append("7. **Move SSH to a non-standard port** (defense-in-depth; reduces log noise and drive-by scanner hits, but is *not* a substitute for key-auth).")
lines.append("8. **Whitelist administrative access** if at all possible: allow SSH/FTP only from trusted source CIDRs, blocking 0.0.0.0/0 at the edge.")
lines.append("")
lines.append("### 7.3 Account & PAM hygiene")
lines.append("")
lines.append("9. **Remove or lock default/service accounts** that do not need interactive login (test, guest, ftp, nobody, operator, games, lp, etc.) — these are exactly the usernames being probed. Set their shell to `/sbin/nologin`.")
lines.append("10. **Enable PAM lockout** (`pam_faillock.so` or `pam_tally2.so`) — e.g. 5 failed attempts → 15-minute lockout — for sshd, login, and ftpd PAM stacks.")
lines.append("11. **Restrict `su` to a wheel group** (`pam_wheel.so`), even though no `su` failures appear in this window.")
lines.append("12. **Enforce strong password policy** (min length ≥ 12, mixed character classes) via `pam_cracklib` for any accounts still using passwords.")
lines.append("")
lines.append("### 7.4 Monitoring & system maintenance")
lines.append("")
lines.append("13. **Ship logs off-box** to a central syslog/SIEM; enable `logrotate` with appropriate retention. This log spans many months in a small window which complicates incident response.")
lines.append("14. **Alert on:** >10 auth failures/min from one source, *any* `root` auth failure, `User unknown` bursts, anonymous FTP logins, klogind/telnet events.")
lines.append("15. **Upgrade the OS.** Kernel 2.6.5-1.358 (Red Hat, circa 2004) has hundreds of known remotely-exploitable vulnerabilities. Migrate to a supported, regularly-patched distribution; a compromised host cannot be secured through configuration alone.")
lines.append("16. **Periodically audit** listening ports (`netstat -tlnp` / `ss -tlnp`) to ensure no unexpected services (like the stray-telnet bind) are exposed.")
lines.append("")
lines.append("---")
lines.append("")
lines.append("## Appendix A — Representative Event Samples")
lines.append("")
lines.append("**SSH brute-force burst targeting `root` (`unknown.sagonet.net`):**")
lines.append("```")
n = 0
with open(LOG, encoding="latin-1", errors="replace") as f:
    for line in f:
        if "unknown.sagonet.net" in line and "authentication failure" in line:
            lines.append(line.rstrip())
            n += 1
            if n >= 5: break
lines.append("```")
lines.append("")
lines.append("**FTP parallel connection flood (`209.184.7.130`):**")
lines.append("```")
n = 0
with open(LOG, encoding="latin-1", errors="replace") as f:
    for line in f:
        if "ftpd" in line and "209.184.7.130" in line and "connection from" in line:
            lines.append(line.rstrip())
            n += 1
            if n >= 8: break
lines.append("```")
lines.append("")
lines.append("**Kerberos klogind replay attack (`163.27.187.39`):**")
lines.append("```")
n = 0
with open(LOG, encoding="latin-1", errors="replace") as f:
    for line in f:
        if "klogind" in line and "163.27.187.39" in line and "Authentication failed" in line:
            lines.append(line.rstrip())
            n += 1
            if n >= 4: break
lines.append("```")
lines.append("")
lines.append("---")
lines.append("*Report generated automatically from syslog.log.*")

out = "/home/user/17b28cfa415a483d96fa9078a1a5764e/auth_failures_report.md"
with open(out, "w") as f:
    f.write("\n".join(lines))
print("WROTE:", out)
print(f"PAM:{total_pam} sshd:{svc_counter.get('sshd',0)} login:{svc_counter.get('login',0)} gdm:{svc_counter.get('gdm',0)}")
print(f"klogind:{total_klogind} ftpd_conns:{total_ftpd_conn} ftpd_anon:{total_ftpd_anon} ftpd_unk:{total_ftpd_unknown}")
print("Top PAM sources:", src_counter.most_common(5))
print("Top users:", user_counter.most_common(5))
print("Top ftp:", ftp_src_summary[:3])
print("Peak day:", peak_day, peak_day_count, "Peak hour:", peak_hour, peak_hour_count)
print("SSH-FTP overlap:", len(overlap))
