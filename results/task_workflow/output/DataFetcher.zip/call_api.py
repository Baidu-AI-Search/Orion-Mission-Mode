#!/usr/bin/env python3
"""
DataFetcher - Automated data fetching utility
Reads API configuration from config.json and calls the endpoint.
"""

import json
import sys
import urllib.request
import urllib.error
from pathlib import Path


def load_config(config_path: str = "config.json") -> dict:
    """Load and parse the JSON configuration file."""
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def call_api(config: dict) -> dict:
    """
    Call the API endpoint defined in config.

    Returns:
        dict with keys: status_code, headers, body (parsed JSON if possible)
    """
    api_cfg = config["api"]
    endpoint = api_cfg["endpoint"]
    method = api_cfg.get("method", "GET").upper()
    headers = api_cfg.get("headers", {})
    timeout = api_cfg.get("timeout", 30)

    req = urllib.request.Request(endpoint, method=method, headers=headers)

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            try:
                body = json.loads(raw)
            except json.JSONDecodeError:
                body = raw
            return {
                "status_code": resp.status,
                "headers": dict(resp.headers),
                "body": body,
            }
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace") if e.fp else ""
        try:
            body = json.loads(raw)
        except json.JSONDecodeError:
            body = raw
        return {
            "status_code": e.code,
            "headers": dict(e.headers) if e.headers else {},
            "body": body,
            "error": f"HTTPError: {e.reason}",
        }
    except urllib.error.URLError as e:
        return {
            "status_code": None,
            "headers": {},
            "body": None,
            "error": f"URLError: {e.reason}",
        }
    except Exception as e:
        return {
            "status_code": None,
            "headers": {},
            "body": None,
            "error": f"Unexpected error: {e}",
        }


def main():
    config_path = sys.argv[1] if len(sys.argv) > 1 else "config.json"
    print(f"[DataFetcher] Loading config from: {config_path}")
    cfg = load_config(config_path)

    project = cfg.get("project", {})
    print(f"[DataFetcher] Project : {project.get('name', 'unknown')} v{project.get('version', '?')}")
    print(f"[DataFetcher] Descr   : {project.get('description', '')}")

    api_cfg = cfg["api"]
    print(f"[DataFetcher] Endpoint: {api_cfg['endpoint']}")
    print(f"[DataFetcher] Method  : {api_cfg.get('method', 'GET')}")
    print(f"[DataFetcher] Timeout : {api_cfg.get('timeout', 30)}s")
    print("[DataFetcher] Calling API ...")

    result = call_api(cfg)

    print(f"[DataFetcher] Status  : {result.get('status_code')}")
    if result.get("error"):
        print(f"[DataFetcher] Error   : {result['error']}")

    print("[DataFetcher] Body    :")
    body = result.get("body")
    if isinstance(body, (dict, list)):
        print(json.dumps(body, indent=2, ensure_ascii=False))
    else:
        print(body if body is not None else "(empty)")

    return 0 if result.get("status_code") == 200 else 1


if __name__ == "__main__":
    sys.exit(main())
