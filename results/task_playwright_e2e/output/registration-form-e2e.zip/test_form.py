"""
End-to-end Playwright test for the 3-step registration form (form.html).

Run:
    pip install playwright
    playwright install chromium
    python test_form.py
"""

import os
import re
import time
from pathlib import Path

from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout


# ---------------- Retry helper ----------------
def retry(action, *, retries: int = 3, delay: float = 0.5, description: str = "action"):
    """Retry an action up to `retries` times with a short delay between attempts."""
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            return action()
        except Exception as e:  # noqa: BLE001
            last_err = e
            print(f"[retry] {description} — attempt {attempt}/{retries} failed: {e}")
            if attempt < retries:
                time.sleep(delay)
    raise last_err


def testid(sel: str) -> str:
    """Build a data-testid selector."""
    return f'[data-testid="{sel}"]'


def fill_with_retry(page, test_id: str, value: str):
    """Focus + fill an input by data-testid with retry."""
    sel = testid(test_id)

    def _do():
        loc = page.locator(sel).first
        loc.wait_for(state="visible", timeout=5000)
        loc.click()
        loc.fill("")
        loc.fill(value)
        # Confirm value took
        actual = loc.input_value()
        assert actual == value, f"Expected {value!r}, got {actual!r}"
        return loc

    return retry(_do, description=f"fill {test_id}")


def select_with_retry(page, test_id: str, value: str):
    def _do():
        loc = page.locator(testid(test_id)).first
        loc.wait_for(state="visible", timeout=5000)
        loc.select_option(value)
        assert loc.input_value() == value
        return loc

    return retry(_do, description=f"select {test_id}")


def click_with_retry(page, test_id: str):
    def _do():
        loc = page.locator(testid(test_id)).first
        loc.wait_for(state="visible", timeout=5000)
        loc.scroll_into_view_if_needed()
        loc.click()
        return loc

    return retry(_do, description=f"click {test_id}")


def assert_step_visible(page, step_num: int, expected_active_progs: int):
    """Assert the given step panel is visible and the progress bar reflects it."""

    def _check():
        # Each step panel: only step-{step_num} has .active
        for s in (1, 2, 3):
            step = page.locator(testid(f"step-{s}"))
            classes = step.get_attribute("class") or ""
            is_active = "active" in classes.split()
            if s == step_num:
                assert is_active, f"step-{s} should be active, got classes={classes!r}"
            else:
                assert not is_active, f"step-{s} should NOT be active, got classes={classes!r}"
        # Progress bar: first N segments are active
        for i in range(1, 4):
            prog = page.locator(f"#prog-{i}")
            classes = prog.get_attribute("class") or ""
            is_active = "active" in classes.split()
            if i <= expected_active_progs:
                assert is_active, f"prog-{i} should be active (expected {expected_active_progs})"
            else:
                assert not is_active, f"prog-{i} should NOT be active (expected {expected_active_progs})"

    retry(_check, description=f"assert step {step_num} visible")


# ---------------- Main test ----------------
def run_test():
    here = Path(__file__).resolve().parent
    form_path = here / "form.html"
    assert form_path.exists(), f"form.html not found at {form_path}"
    url = form_path.as_uri()

    form_data = {
        "fullname": "Jane Doe",
        "email": "jane.doe@example.com",
        "phone": "+1 555-123-4567",
        "street": "123 Main Street",
        "city": "San Francisco",
        "state": "CA",
        "zip": "94102",
    }
    expected_address = (
        f"{form_data['street']}, {form_data['city']}, {form_data['state']} {form_data['zip']}"
    )

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(viewport={"width": 1280, "height": 900})
        page = context.new_page()

        print(f"Navigating to {url}")
        page.goto(url, wait_until="domcontentloaded")
        page.wait_for_selector(testid("form-container"), state="visible")

        # ---- Step 1: Personal Info ----
        print("Step 1: filling personal info")
        assert_step_visible(page, step_num=1, expected_active_progs=1)

        fill_with_retry(page, "fullname", form_data["fullname"])
        fill_with_retry(page, "email", form_data["email"])
        fill_with_retry(page, "phone", form_data["phone"])

        # No error messages should be visible
        for err_id in ("err-fullname", "err-email", "err-phone"):
            err = page.locator(f"#{err_id}")
            assert "visible" not in (err.get_attribute("class") or "").split(), (
                f"{err_id} should not be visible"
            )

        click_with_retry(page, "next-1")

        # ---- Step 2: Address ----
        print("Step 2: filling address")
        assert_step_visible(page, step_num=2, expected_active_progs=2)

        fill_with_retry(page, "street", form_data["street"])
        fill_with_retry(page, "city", form_data["city"])
        select_with_retry(page, "state", form_data["state"])
        fill_with_retry(page, "zip", form_data["zip"])

        for err_id in ("err-street", "err-city", "err-state", "err-zip"):
            err = page.locator(f"#{err_id}")
            assert "visible" not in (err.get_attribute("class") or "").split(), (
                f"{err_id} should not be visible"
            )

        click_with_retry(page, "next-2")

        # ---- Step 3: Review & Submit ----
        print("Step 3: reviewing and submitting")
        assert_step_visible(page, step_num=3, expected_active_progs=3)

        def _verify_review():
            checks = {
                "review-fullname": form_data["fullname"],
                "review-email": form_data["email"],
                "review-phone": form_data["phone"],
                "review-address": expected_address,
            }
            for tid, expected in checks.items():
                text = page.locator(testid(tid)).inner_text(timeout=3000)
                assert text.strip() == expected, f"{tid}: expected {expected!r}, got {text.strip()!r}"

        retry(_verify_review, description="verify review summary")

        click_with_retry(page, "submit")

        # ---- Success panel ----
        print("Verifying success panel")

        def _verify_success():
            panel = page.locator(testid("success-panel"))
            panel.wait_for(state="visible", timeout=5000)
            # After submit, step-3 is no longer active; success-panel is shown.
            display = panel.evaluate("el => getComputedStyle(el).display")
            assert display != "none", "success-panel should be displayed"
            sub_id_el = page.locator(testid("submission-id"))
            sub_id = sub_id_el.inner_text().strip()
            assert sub_id, "submission-id should not be empty"
            assert re.match(r"^REG-[A-Z0-9]{8}$", sub_id), (
                f"submission ID has unexpected format: {sub_id!r}"
            )
            return sub_id

        submission_id = retry(_verify_success, description="verify success panel")
        print(f"Submission ID: {submission_id}")

        # Save screenshot of final success state
        out_path = here / "success.png"
        page.screenshot(path=str(out_path), full_page=True)
        print(f"Screenshot saved to {out_path}")

        browser.close()
        print("All checks passed ✅")
        return submission_id


if __name__ == "__main__":
    run_test()
